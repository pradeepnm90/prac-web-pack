import { DropdownMenuItem } from "../model/global-btn.model";

export interface DropdownMenuState {
    menus: DropdownMenuItem[];
}