export interface DropdownMenuItem {
    menuItems: string[];
}